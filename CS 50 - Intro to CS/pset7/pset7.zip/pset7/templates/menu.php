<div>
    <a href="sell.php">Buy</a>
    |
    <a href="history.php">History</a>
    |
    <a href="quote.php">Quote</a>
    |
    <a href="sell.php">Sell</a>
    |
    <a href="logout.php"><strong>Log Out<strong></a>
</div>
