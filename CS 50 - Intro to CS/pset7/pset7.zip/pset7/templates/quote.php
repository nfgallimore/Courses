A share of <?= htmlspecialchars($stock["name"]) ?> (<?= htmlspecialchars($stock["symbol"]) ?>) costs <strong>$<?= number_format($stock["price"], 2) ?></strong>.
