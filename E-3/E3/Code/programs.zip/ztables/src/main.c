#include "lib/ztables.h"

int main(int argc, char **argv)
{
	double start = 0;
	double end = 0;
	double mean = 0;
	double sd = 0;
	double p = 0;
	double n = 0;
	double stdevv = 0;
	if (argc != 6 && argc != 4)
	{
		printf("\n\nUsage: \n\nTo Compute Probabliity Density on Normal Distribution\n      ./ztables -zt <start> <end> <mean> <stdeviation>\n\n\n");
		printf("To Compute Standard Deviation:\n       ./ztables -sd <p> <n>\n\n\n");
		if (argc != 1) return 0;
	}

	if (argc == 1)
	{
		printf("Computing Z-Table Lookup: \n");
		printf("\nEnter the start point: ");
		start = GetDouble();
		printf("\nEnter the end point: ");
		end = GetDouble();
		printf("\nEnter the mean: ");
		mean = GetDouble();
		printf("\nEnter the standard deviation: ");
		sd = GetDouble();
	}
	if (argc == 6 && strcmp(argv[1], "-zt") == 0)
	{	
		start = strtod(argv[2], NULL);
		end = strtod(argv[3], NULL);
		mean = strtod(argv[4], NULL);
		sd = strtod(argv[5], NULL);
	}
	else if (argc == 4 && strcmp(argv[1], "-sd") == 0)
	{
		p = strtod(argv[2], '\0');
		n = strtod(argv[3], '\0');
		printf("%.3lf%%\n", stdev(p, n));
		return 0;
	}
	ztable(start, end, mean, sd);
	return 0;
}
