#include "../lib/ztables.h"

bool ztable(double start, double end, double mean, double sd)
{
	double zt_start = ztablefunc(sd, start, mean);
	double zt_end = ztablefunc(sd, end, mean);

	load(zt_start);
	double z1 = d2;
	print_zt(start, mean);

	load(zt_end);
	double z2 = d2;
	print_zt(end, mean);

	print_result(z1, z2);

	unload();
	return true;
}

double 
ztablefunc(double sigma, double x, double n)
{
	double z = x - n;
	z = z / sigma;
	if (z < 0) z *= -1.0;
	return z;
}