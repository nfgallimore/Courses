/****************************************************************************
 * ztables.h
 *
 * Nick Gallimore <ngallimore@fas.harvard.edu>
 *
 *  Implements Z-Tables for probability density function's on a 
 *	normal distribution graph.
 * 
 ***************************************************************************/


#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>
#include "cs50/cs50.h"


typedef struct
{
	double z;
	double between;
	double beyond;
} z_val;


typedef struct node
{
	z_val val;
	struct node *next;
} node;


node *list;

bool ztable(double start, double end, double mean, double sd);
bool unload(void);
double ztablefunc(double sigma, double p, double n);
double stdev(double p, double n);
bool load();
bool search(double zt);
void print_zt();
double print_result(double z_1, double z_2, double start, double end, double mean);
double sqrt(double x); 
double d1, d2, d3;
