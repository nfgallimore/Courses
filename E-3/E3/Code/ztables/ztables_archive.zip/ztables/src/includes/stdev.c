#include "../lib/ztables.h"

double
stdev(double p, double n)
{
	p = p * (1.0 - p) / n;
	p = sqrt(p) * sqrt(p) / sqrt(p);
	return p * 100;
}
