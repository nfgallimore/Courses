#include "../lib/ztables.h"

bool search(double zt)
{
	while (zt - list->val.z >= .5) 
	{
		list = list->next;
		if (zt - list->val.z < .5) return true;
	}
	return false;
}


bool
load(double zt)
{
	d1 = 0, d2 = 0, d3 = 0;
	FILE *fp = fopen("src/lib/tables", "r");
	if (fp == NULL) return false;
	while (!feof(fp))
	{
		if (zt - d1 < .05) return true;
		fscanf(fp, "%lf %lf %lf", &d1, &d2, &d3);

		node *entry = malloc(sizeof(node));

		if (entry == NULL) 
		{ 
			unload();
			fclose(fp);
			return false; 
		}
		// set values
		entry->val.z = d1;
		entry->val.between = d2;
		entry->val.beyond = d3;


		// append to list
		entry->next = list;
		list = entry;

		if (ferror(fp))
    	{
        	unload();
        	fclose(fp);
        	return false;
    	}
	};

	fclose(fp);
	unload();
	return true;
}


bool 
unload()
{
	while (list != NULL)
	{
		node *current = list->next;
		free(list);
		list = current;
	}
	return true;
}
