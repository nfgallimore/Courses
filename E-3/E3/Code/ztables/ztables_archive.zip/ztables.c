/****************************************************************************
 * ztables.c
 *
 * Nick Gallimore <ngallimore@fas.harvard.edu>
 *
 *  Implements Z-Tables for probability density function's on a 
 *	normal distribution graph.
 * 
 ***************************************************************************/
/***************************************************************************//*
    Copyright (C) 2013 Nick Gallimore

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>


typedef struct
{
	double z;
	double between;
	double beyond;
} z_val;


typedef struct node
{
	z_val val;
	struct node *next;
} node;


node *list;

bool ztable(double start, double end, double mean, double sd);
bool unload(void);
double ztablefunc(double sigma, double p, double n);
double stdev(double p, double n);
bool load();
bool search(double zt);
double d1, d2, d3;
void print_zt();
double print_result(double z_1, double z_2);


int main(int argc, char* argv[])
{
	double start = 0;
	double end = 0;
	double mean = 0;
	double sd = 0;

	if (strcmp(argv[1], "-zt") == 0)
	{	
		start = atoi(argv[2]);
		end = atoi(argv[3]);
		mean = atoi(argv[4]);
		sd = atoi(argv[5]);
		ztable(start, end, mean, sd);
	}
	else if (strcmp(argv[1], "-sd") == 0)
	{
		double p = atoi(argv[2]);
		double n = atoi(argv[3]);
		double stdevv = stdev(p,n);
		printf("%lf", stdevv);
	}
	else 
	{
		printf("\n\nUsage: \n\nTo Compute Probabliity Density on Normal Distribution\n      ./ztables -zt <start> <end> <mean> <stdeviation>\n\n\n");
		printf("To Compute Standard Deviation:\n       ./ztables -sd <p> <n>\n\n\n");
	}
	return 0;
}

bool ztable(double start, double end, double mean, double sd)
{
	double zt_start = ztablefunc(sd, start, mean);
	double zt_end = ztablefunc(sd, end, mean);

	load(zt_start);
	double z1 = d2;
	print_zt(start, mean);

/* TODO
	z_val *point1 = malloc(sizeof(z_val));
	z_val *point2 = malloc(sizeof(z_val));

	point1.z = ztablefunc(sd, start, mean);
	point2.z = ztablefunc(sd, start, mean);
*/

	load(zt_end);
	double z2 = d2;
	print_zt(end, mean);

	print_result(z1, z2);

	unload();
	return true;
}


double print_result(double z_1, double z_2)
{
	double result = (z_1 - z_2) * 100;
	if (result < 0) result = (z_2 + z_1) *100;
	printf("\nThe result is %.2lf percent.\n\n", result); 
	
	return result;
}	


void print_zt(double n, double mean)
{
	printf("\n\nPOINT (%.2lf) DISTANCE FROM MEAN (%.2lf) \n", n, mean);
	printf("--------------------------------------------------------\n");
	printf("Z: %.1lf\nArea between the mean and X: %.4lf\nArea beyond X: %.4lf\n\n", d1, d2, d3);
}


bool search(double zt)
{
	while (zt - list->val.z >= .5) 
	{
		list = list->next;
		if (zt - list->val.z < .5) return true;
	}
	return false;
}


bool
load(double zt)
{
	d1 = 0, d2 = 0, d3 = 0;
	FILE *fp = fopen("Z-table.txt", "r");
	if (fp == NULL) return false;
	while (!feof(fp))
	{
		if (zt - d1 < .05) return true;
		fscanf(fp, "%lf %lf %lf", &d1, &d2, &d3);

		node *entry = malloc(sizeof(node));

		if (entry == NULL) 
		{ 
			unload();
			fclose(fp);
			return false; 
		}
		// set values
		entry->val.z = d1;
		entry->val.between = d2;
		entry->val.beyond = d3;


		// append to list
		entry->next = list;
		list = entry;

		if (ferror(fp))
    	{
        	unload();
        	fclose(fp);
        	return false;
    	}
	};

	fclose(fp);
	unload();
	return true;
}


bool 
unload()
{
	while (list != NULL)
	{
		node *current = list->next;
		free(list);
		list = current;
	}
	return true;
}


double 
stdev(double p, double n)
{
	double sigma = abs((p * (1.0 - p) / n));
	sigma = sqrt(sigma);
	return sigma;
}


double 
ztablefunc(double sigma, double x, double n)
{
	double z = x - n;
	z = z / sigma;
	if (z < 0) z *= -1.0;
	return z;
}