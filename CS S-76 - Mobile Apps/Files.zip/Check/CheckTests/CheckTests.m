//
//  CheckTests.m
//  CheckTests
//
//  Created by Gallimore, Nicholas Fredrick on 6/28/13.
//  Copyright (c) 2013 Gallimore, Nicholas Fredrick. All rights reserved.
//

#import "CheckTests.h"

@implementation CheckTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in CheckTests");
}

@end
