//
//  CheckTests.h
//  CheckTests
//
//  Created by Gallimore, Nicholas Fredrick on 6/28/13.
//  Copyright (c) 2013 Gallimore, Nicholas Fredrick. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CheckTests : SenTestCase

@end
