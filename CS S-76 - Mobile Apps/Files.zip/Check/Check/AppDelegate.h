//
//  AppDelegate.h
//  Check
//
//  Created by Gallimore, Nicholas Fredrick on 6/28/13.
//  Copyright (c) 2013 Gallimore, Nicholas Fredrick. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
