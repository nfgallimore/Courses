//
//  ViewController.h
//  Check
//
//  Created by Gallimore, Nicholas Fredrick on 6/28/13.
//  Copyright (c) 2013 Gallimore, Nicholas Fredrick. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface ViewController : GLKViewController

@end
